from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Course)
admin.site.register(Section)
admin.site.register(Class)
admin.site.register(Session)
admin.site.register(Block)
admin.site.register(Room)
